public class Column extends SuperClass{

    Column(int length){
        super(length);
    }
    
}
