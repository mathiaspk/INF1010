public class Row extends SuperClass{
  
    Row(int length){
        super(length);
    }
    
}
