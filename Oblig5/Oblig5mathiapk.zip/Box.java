public class Box extends SuperClass{
    Box(int length){
        super(length);
    }
}
